#include <stdio.h>
#include <stdlib.h>

void selection_sort(long *, unsigned long );
void iaprintf(long *, unsigned long);
void iascanf(long *, unsigned long);


